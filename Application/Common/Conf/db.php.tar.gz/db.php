<?php
// 数据库配置
return array(
	'DB_TYPE'   => 'mysql',       // 数据库类型
	'DB_HOST'   => 'rm-baowangneis.mysql.rds.aliyuncs.com',       // 服务器地址
	'DB_NAME'   => 'xiaodipay',       // 数据库名
	'DB_USER'   => 'baowangshuju',       // 用户名
	'DB_PWD'    => 'caiwudi1989!!!!',        // 密码
	'DB_PORT'   => '3306',       // 端口
	'DB_PREFIX' => 'pays_',     // 数据库表前缀
	'SYS_KEY'    => 'SN20180824202337', 
);

